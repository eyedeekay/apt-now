# hdpage
emits an HTML fragment for a page header using arguments or environment variables.
