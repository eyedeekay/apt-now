#
# Regular cron jobs for the go-uhttpd package
#
0 4	* * *	root	[ -x /usr/bin/go-uhttpd_maintenance ] && /usr/bin/go-uhttpd_maintenance
