# Defaults for go-uhttpd initscript
# sourced by /etc/init.d/go-uhttpd
# installed at /etc/default/go-uhttpd by the maintainer scripts

#
# This is a POSIX shell fragment
#

# Additional options that are passed to the Daemon.
DAEMON_OPTS=""
