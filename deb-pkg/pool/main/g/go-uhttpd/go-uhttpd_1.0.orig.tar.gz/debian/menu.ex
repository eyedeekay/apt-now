?package(go-uhttpd):needs="X11|text|vc|wm" section="Applications/see-menu-manual"\
  title="go-uhttpd" command="/usr/bin/go-uhttpd"
